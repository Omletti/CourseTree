// Course category expansion
document.querySelectorAll('.course-header').forEach(header => {
    header.addEventListener('click', () => {
        const category = header.parentElement;
        category.classList.toggle('active');
    });
});

// Course selection
document.querySelectorAll('.course-item').forEach(course => {
    course.addEventListener('click', () => {
        const courseName = course.textContent;
        addCourseTag(courseName);
        updateCourseDetails(courseName);
    });
});

// Search functionality
const searchInput = document.querySelector('.search-box input');
searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    
    document.querySelectorAll('.course-item').forEach(course => {
        const courseText = course.textContent.toLowerCase();
        const shouldShow = courseText.includes(searchTerm);
        course.style.display = shouldShow ? 'block' : 'none';
    });
});

// Add course tag
function addCourseTag(courseName) {
    const courseTags = document.querySelector('.course-tags');
    
    // Check if course is already added
    if (document.querySelector(`.course-tag[data-course="${courseName}"]`)) {
        return;
    }
    
    const tag = document.createElement('div');
    tag.className = 'course-tag';
    tag.setAttribute('data-course', courseName);
    tag.innerHTML = `
        <span>${courseName}</span>
        <button class="remove-tag">×</button>
    `;
    
    tag.querySelector('.remove-tag').addEventListener('click', () => {
        tag.remove();
        updateVisualization();
    });
    
    courseTags.appendChild(tag);
    updateVisualization();
}

// Update course details in right sidebar
function updateCourseDetails(courseName) {
    const courseDetails = document.querySelector('.course-details');
    
    // This is where you would normally fetch course details from your backend
    // For now, we'll just show some placeholder data
    courseDetails.innerHTML = `
        <h4>${courseName}</h4>
        <div class="course-info">
            <p><strong>Prerequisites:</strong> None</p>
            <p><strong>Units:</strong> 12</p>
            <p><strong>Description:</strong> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
    `;
}

// Update visualization
function updateVisualization() {
    const selectedCourses = Array.from(document.querySelectorAll('.course-tag'))
        .map(tag => tag.getAttribute('data-course'));
    
    const visualizationArea = document.querySelector('.visualization-area');
    
    if (selectedCourses.length === 0) {
        visualizationArea.innerHTML = `
            <div class="placeholder-message">
                <i class="fas fa-tree"></i>
                <h3>Select courses to visualize your course tree</h3>
                <p>Choose courses from the left sidebar to begin</p>
            </div>
        `;
    } else {
        // This is where you would normally generate the tree visualization
        // For now, we'll just show the selected courses
        visualizationArea.innerHTML = `
            <div class="selected-courses-list">
                <h3>Selected Courses:</h3>
                <ul>
                    ${selectedCourses.map(course => `<li>${course}</li>`).join('')}
                </ul>
            </div>
        `;
    }
}

// Clear button functionality
document.querySelector('.clear-btn').addEventListener('click', () => {
    document.querySelector('.course-tags').innerHTML = '';
    updateVisualization();
});

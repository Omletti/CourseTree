import React from "react";

const Maincontent = () => {
  return (
    <div class="main-content">
      <div class="header">
        <div class="selected-courses">
          <h2>Selected Courses</h2>
          <div class="course-tags">{/* Course tags will be added here dynamically */}</div>
        </div>
        <div class="controls">
          <button class="generate-btn">
            <i class="fas fa-wand-magic-sparkles"></i>
            Generate Schedule
          </button>
          <button class="clear-btn">
            <i class="fas fa-trash"></i>
            Clear
          </button>
        </div>
      </div>
      <div class="visualization-area">
        <div class="placeholder-message">
          <i class="fas fa-tree"></i>
          <h3>Select course to visualize your course tree</h3>
          <p>Choose course from the left sidebar to begin</p>
        </div>
      </div>
    </div>
  );
};

export default Maincontent;

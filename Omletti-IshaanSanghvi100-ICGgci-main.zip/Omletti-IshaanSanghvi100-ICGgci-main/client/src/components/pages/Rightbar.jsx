import React from "react";

const Rightbar = () => {
  return (
    <div class="sidebar right-sidebar">
      <div class="info-section">
        <h3>Course Information</h3>
        <div class="course-details">
          <p class="select-course-message">Select a course to view details</p>
        </div>
      </div>
      <div class="legend">
        <h4>Prerequisites</h4>
        <div class="legend-item">
          <span class="dot no-prereq"></span>
          <span>No Prerequisites</span>
        </div>
        <div class="legend-item">
          <span class="dot one-prereq"></span>
          <span>1 Prerequisite</span>
        </div>
        <div class="legend-item">
          <span class="dot two-prereq"></span>
          <span>2 Prerequisites</span>
        </div>
        <div class="legend-item">
          <span class="dot three-prereq"></span>
          <span>3+ Prerequisites</span>
        </div>
      </div>
    </div>
  );
};

export default Rightbar;

import React, { useContext } from "react";
import { UserContext } from "../App"; // so you can call handleLogin
import { GoogleLogin, googleLogout } from "@react-oauth/google";
import "../../utilities.css"; // if you need shared CSS
import "./Skeleton.css"; // or create a dedicated Sidebar.css if you want

const Leftbar = () => {
  const { userId, handleLogin, handleLogout } = useContext(UserContext);

  return (
    <div class="sidebar left-sidebar">
      <div class="logo-container">
        <img src="coursetree.png" alt="CourseTree" class="logo" />
        <h1>CourseTree</h1>
        {userId ? (
          <button
            className="login-btn"
            onClick={() => {
              googleLogout();
              handleLogout();
            }}
          >
            <i className="fas fa-user"></i>
            Logout
          </button>
        ) : (
          <GoogleLogin onSuccess={handleLogin} onError={(err) => console.log(err)} />
        )}
      </div>
      <div class="search-box">
        <i class="fas fa-search"></i>
        <input type="text" placeholder="Search courses..." />
      </div>
      <div class="course-list">
        {/* <!-- Course 1 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course1">
            <i class="fas fa-building"></i>
            <span>Course 1: Civil and Environmental Engineering</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 2 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course2">
            <i class="fas fa-cogs"></i>
            <span>Course 2: Mechanical Engineering</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 3 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course3">
            <i class="fas fa-atom"></i>
            <span>Course 3: Materials Science and Engineering</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 4 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course4">
            <i class="fas fa-landmark"></i>
            <span>Course 4: Architecture</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 5 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course5">
            <i class="fas fa-flask"></i>
            <span>Course 5: Chemistry</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 6 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course6">
            <i class="fas fa-laptop-code"></i>
            <span>Course 6: Electrical Engineering and Computer Science</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses">
            <div class="course-item">6-3: Computer Science and Engineering</div>
            <div class="course-item">6-7: Computer Science and Molecular Biology</div>
            <div class="course-item">6-9: Computation and Cognition</div>
            <div class="course-item">6-14: Computer Science, Economics, and Data Science</div>
          </div>
        </div>

        {/* <!-- Course 7 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course7">
            <i class="fas fa-dna"></i>
            <span>Course 7: Biology</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 8 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course8">
            <i class="fas fa-atom"></i>
            <span>Course 8: Physics</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 9 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course9">
            <i class="fas fa-brain"></i>
            <span>Course 9: Brain and Cognitive Sciences</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 10 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course10">
            <i class="fas fa-industry"></i>
            <span>Course 10: Chemical Engineering</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 11 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course11">
            <i class="fas fa-city"></i>
            <span>Course 11: Urban Studies and Planning</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 12 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course12">
            <i class="fas fa-globe-americas"></i>
            <span>Course 12: Earth, Atmospheric, and Planetary Sciences</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 14 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course14">
            <i class="fas fa-chart-line"></i>
            <span>Course 14: Economics</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 15 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course15">
            <i class="fas fa-briefcase"></i>
            <span>Course 15: Management</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 16 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course16">
            <i class="fas fa-rocket"></i>
            <span>Course 16: Aeronautics and Astronautics</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 17 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course17">
            <i class="fas fa-balance-scale"></i>
            <span>Course 17: Political Science</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 18 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course18">
            <i class="fas fa-square-root-alt"></i>
            <span>Course 18: Mathematics</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 20 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course20">
            <i class="fas fa-microscope"></i>
            <span>Course 20: Biological Engineering</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 21 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course21">
            <i class="fas fa-book"></i>
            <span>Course 21: Humanities</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>

        {/* <!-- Course 22 --> */}
        <div class="course-category">
          <div class="course-header" data-category="course22">
            <i class="fas fa-radiation"></i>
            <span>Course 22: Nuclear Science and Engineering</span>
            <i class="fas fa-chevron-right"></i>
          </div>
          <div class="subcourses"></div>
        </div>
      </div>
    </div>
  );
};

export default Leftbar;

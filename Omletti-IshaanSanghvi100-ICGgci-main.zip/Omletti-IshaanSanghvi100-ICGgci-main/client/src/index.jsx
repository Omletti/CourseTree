import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import App from "./components/App";
import Skeleton from "./components/pages/Skeleton";
import NotFound from "./components/pages/NotFound";

import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider
} from 'react-router-dom'

import { GoogleOAuthProvider } from '@react-oauth/google';

//TODO: REPLACE WITH YOUR OWN CLIENT_ID
const GOOGLE_CLIENT_ID = "28441211618-q6mc8gscmb0kpsco4om3tob5oetrb3ne.apps.googleusercontent.com";

const CourseTree = () => {
    const [selectedCourses, setSelectedCourses] = useState([]);
    const [searchText, setSearchText] = useState('');

    useEffect(() => {
        // Add click handlers for course headers
        const headers = document.querySelectorAll('.course-header');
        headers.forEach(header => {
            header.addEventListener('click', () => {
                const category = header.closest('.course-category');
                if (category) {
                    category.classList.toggle('active');
                }
            });
        });

        // Add click handlers for course items
        const items = document.querySelectorAll('.course-item');
        items.forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                const courseText = item.textContent.trim();
                const match = courseText.match(/\(([\d\-A-Z]+)\)/);
                if (match && !selectedCourses.includes(match[1])) {
                    setSelectedCourses(prev => [...prev, match[1]]);
                }
            });
        });

        // Cleanup
        return () => {
            headers.forEach(header => {
                header.removeEventListener('click');
            });
            items.forEach(item => {
                item.removeEventListener('click');
            });
        };
    }, []);

    // Handle search
    const handleSearch = (e) => {
        const searchValue = e.target.value.toLowerCase();
        setSearchText(searchValue);

        document.querySelectorAll('.course-category').forEach(category => {
            const header = category.querySelector('.course-header span');
            const items = category.querySelectorAll('.course-item');
            let shouldShow = false;

            if (header && header.textContent.toLowerCase().includes(searchValue)) {
                shouldShow = true;
            }

            items.forEach(item => {
                if (item.textContent.toLowerCase().includes(searchValue)) {
                    shouldShow = true;
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });

            category.style.display = shouldShow ? 'block' : 'none';
            if (shouldShow && searchValue) {
                category.classList.add('active');
            } else if (!searchValue) {
                category.classList.remove('active');
            }
        });
    };

    // Handle course removal
    const handleRemoveCourse = (courseNumber) => {
        setSelectedCourses(prev => prev.filter(course => course !== courseNumber));
    };

    return (
        <div className="app-container">
            <div className="sidebar">
                <div className="search-box">
                    <i className="fas fa-search"></i>
                    <input 
                        type="text" 
                        placeholder="Search courses..." 
                        value={searchText}
                        onChange={handleSearch}
                    />
                </div>
                <div className="course-list">
                    {/* Course list is rendered from HTML */}
                </div>
            </div>
            <div className="main-content">
                <div className="header">
                    <div className="selected-courses">
                        <h2>Choose Your Major</h2>
                        <div className="course-tags">
                            {selectedCourses.map(courseNumber => {
                                const courseItem = document.querySelector(`.course-item:contains("(${courseNumber})")`);
                                const courseText = courseItem ? courseItem.textContent.trim() : courseNumber;
                                return (
                                    <div key={courseNumber} className="course-tag">
                                        {courseText}
                                        <button 
                                            className="remove-tag"
                                            onClick={() => handleRemoveCourse(courseNumber)}
                                        >
                                            <i className="fas fa-times"></i>
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
                <div className="visualization-area">
                    {selectedCourses.length === 0 ? (
                        <div className="placeholder-message">
                            <i className="fas fa-graduation-cap"></i>
                            <h3>Select your major to begin</h3>
                            <p>Choose from the course list on the left</p>
                        </div>
                    ) : (
                        <div className="course-details">
                            {/* Course details will be added here */}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route errorElement={<NotFound />} element={<App />}>
      <Route path="/" element={<Skeleton />}/>
    </Route>
  )
)

// renders React Component "Root" into the DOM element with ID "root"
ReactDOM.createRoot(document.getElementById("root")).render(
  <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
    <RouterProvider router={router} />
    <CourseTree />
  </GoogleOAuthProvider>
);
